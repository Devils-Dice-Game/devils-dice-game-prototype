import React, { Fragment } from "react";
import { StyleSheet, View, TouchableHighlight, Text, Dimensions } from "react-native";
import { Accelerometer, Haptic } from "expo";
import { Platform } from "react-native";

import Dice from "./src/components/Dice";
import QuadDice from "./src/components/QuadDice";
import Modal from "./src/components/Modal";
import Card from "./src/components/Card";
import RuleDisplay from "./src/components/RuleDisplay";
import RuleDescription from "./src/components/RuleDescription";
import DareDisplay from "./src/components/DareDisplay";
import Triple7s from "./src/components/Triple7s";
import { computeRule, rules } from "./src/util/rules";
import TermsAndConditions from "./src/components/TermsAndConditions";
import ShakeDetector from "./src/components/ShakeDetector";
import getNewDare from "./src/util/getNewDare";
import rollDice, { isTriple7s } from "./src/util/rollDice";

global.debug = false;

const addRollToList = (rollRecord, newRollName) => {
  const newRecord = rollRecord.slice(1);
  newRecord.push(newRollName);

  return newRecord;
};

const ruleWasRepeated = rollRecord => {
  const newRule = rollRecord[rollRecord.length - 1];
  const lastRule = rollRecord[rollRecord.length - 2];

  // to prevent Captain's Hat from coming up while a captain exists
  const lastNineRolls = rollRecord.slice(0, 9)
  if(newRule === rules.captainsHat.name && lastNineRolls.includes(rules.captainsHat.name)) {
    return true;
  }

  if (newRule === rules.socials.name || lastRule === rules.socials.name)
    return false;
  return newRule === lastRule;
};

class App extends React.Component {
  state = {
    diceValues: [],
    displayingRuleDescription: false,
    dare: null,
    displayingDare: false,
    playingTriple7s: false,
    termsConditionsAccepted:
      process.env.NODE_ENV === "development" ? true : false,
    difficultHotseatCount: null,
    rollRecord: new Array(10).fill(""),
    justFinishedQuadDice: false,
    captainsHatCounter: null,
    displayCaptainsHatModal: false,
  };

  playTriple7s = () => {
    this.setState({
      playingTriple7s: true,
    });
  };

  stopPlayingTriple7s = () => {
    this.setState({
      playingTriple7s: false,
    });
  };

  playCaptainsHat = () => {
    if(this.state.captainsHatCounter === null) {
      this.setState({
        captainsHatCounter: 9
      })
    } else if (this.state.captainsHatCounter === 0) {
      this.setState({
        displayCaptainsHatModal: true,
        captainsHatCounter: null,
      })
    } else {
      this.setState(prevState => ({
        captainsHatCounter: prevState.captainsHatCounter - 1,
      }))
    }
  }

  disableCaptainsHatModal = () => {
    this.setState({
      displayCaptainsHatModal: false,
    })
  }

  roll = () => {
    if (Platform.OS === "ios") {
      Haptic.impact(Haptic.ImpactFeedbackStyle.Heavy);
    }
    let diceValues = rollDice(2);
    let rule = computeRule(diceValues);

    let rollRecord = addRollToList(this.state.rollRecord, rule.name);

    while (ruleWasRepeated(rollRecord)) {
      diceValues = rollDice(2);
      rule = computeRule(diceValues);
      rollRecord = addRollToList(this.state.rollRecord, rule.name);
    }

    let dare = getNewDare(rule);

    if(rule === rules.captainsHat || this.state.captainsHatCounter !== null) {
      this.playCaptainsHat();
    }

    if (isTriple7s(rollRecord)) {
      this.playTriple7s();
    } else {
      // reset values unrelated to current roll back to defaults
      this.setState({
        diceValues,
        dare,
        rollRecord,
        displayingRuleDescription: false,
        displayingDare: false,
        difficultHotseatCount:
          rule.name === rules.difficultHotseat.name ? 0 : null,
        playingTriple7s: false,
        justFinishedQuadDice: false,
        quadDice: null,
      });
    }
  };

  rollQuadDice = () => {
    this.setState({
      quadDice: rollDice(4),
      justFinishedQuadDice: true,
    });
  };

  toggleRuleDescription = () => {
    this.setState(prevState => ({
      displayingRuleDescription: !prevState.displayingRuleDescription,
    }));
  };

  disableDareDisplay = () => {
    this.setState({
      displayingDare: false,
    });
  };

  displayDare = () => {
    const rule = computeRule(this.state.diceValues)
    const dare = getNewDare(rule);
    this.setState({
      dare: dare,
      displayingDare: true,
    });
  };

  acceptTermsAndConditions = () => {
    this.setState({
      termsConditionsAccepted: true,
    });
  };

  playDifficultHotseat = () => {
    const difficultHotseatDare = getNewDare(rules.difficultHotseat);
    this.setState(prevState => ({
      difficultHotseatCount:
        prevState.difficultHotseatCount >= 5
          ? null
          : prevState.difficultHotseatCount + 1,
      difficultHotseatDare,
    }));
  };

  renderCard = (rule, rollFunction, rollText) => {
    const {
      difficultHotseatCount,
      dare,
      difficultHotseatDare,
      displayingDare,
      quadDice,
    } = this.state;

    if (rule === rules.difficultHotseat) {
      if (difficultHotseatCount === null) {
        // game is over, prompt user to move onto next roll
        return (
          <Card
            dare={null}
            displayDare={this.displayDare}
            primaryButtonFunction={rollFunction}
            rollText={rollText}
            textToDisplay={"Well done! Next up!"}
            playingDifficultHotseat={isPlayingDifficultHotseat(
              difficultHotseatCount
            )}
            style={styles.bottomCard}
            displayingDare={false}
            maxHeight={this.state.ruleDescriptionHeight}
            minHeight={this.state.diceHeight}
            ruleName={rule.name}
          />
        );
      }

      const textToDisplay =
        difficultHotseatCount === 0 ? rule.description : difficultHotseatDare;

      return (
        <Card
          dare={dare}
          displayDare={this.displayDare}
          primaryButtonFunction={rollFunction}
          rollText={rollText}
          textToDisplay={textToDisplay}
          playingDifficultHotseat={isPlayingDifficultHotseat(
            difficultHotseatCount
          )}
          style={styles.bottomCard}
          displayingDare={difficultHotseatCount > 0}
          maxHeight={this.state.ruleDescriptionHeight}
          minHeight={this.state.diceHeight}
          ruleName={rule.name}
        />
      );
    } else {
      let textToDisplay = displayingDare ? dare : rule.description;
      if (this.state.justFinishedQuadDice)
        textToDisplay = `Drink for ${sumArray(quadDice)} seconds!`;
      return (
        <Card
          dare={dare}
          displayDare={this.displayDare}
          primaryButtonFunction={rollFunction}
          rollText={rollText}
          textToDisplay={textToDisplay}
          playingDifficultHotseat={isPlayingDifficultHotseat(
            difficultHotseatCount
          )}
          style={styles.bottomCard}
          displayingDare={displayingDare}
          maxHeight={this.state.ruleDescriptionHeight}
          minHeight={this.state.diceHeight}
          ruleName={rule.name}
        />
      );
    }
  };

  renderDice = rule => {
    const { diceValues, quadDice, difficultHotseatCount } = this.state;
    const currentGame = computeRule(diceValues);
    if (currentGame === rules.quadDice && quadDice) {
      return <Dice diceValues={quadDice} getBottomOfDiceDisplay={this.getBottomOfDiceDisplay} />;
    } else {
      return (
        <MainDice
          diceValues={diceValues}
          rule={rule}
          toggleRuleDescription={this.toggleRuleDescription}
          difficultHotseatCount={difficultHotseatCount}
          getBottomOfDiceDisplay={this.getBottomOfDiceDisplay}
        />
      );
    }
  };

  getBottomOfRuleDisplay = event => {
    const { height } = event.nativeEvent.layout;

    const deviceHeight = Dimensions.get('window').height;
    const ruleDescriptionHeight = deviceHeight - height - 125;

    this.setState({
      ruleDescriptionHeight,
    })
  }

  getBottomOfDiceDisplay = event => {
    const { height } = event.nativeEvent.layout;
    const layout = event.nativeEvent.layout;
    
    const deviceHeight = Dimensions.get('window').height;
    const diceHeight = this.state.ruleDescriptionHeight - height - 125;

    this.setState({
      diceHeight,
    })
  }

  render() {
    const {
      diceValues,
      difficultHotseatCount,
      displayingRuleDescription,
      dare,
      justFinishedQuadDice,
    } = this.state;

    const rule = computeRule(diceValues);
    const { rollFunction, rollText } = currentRollState(
      difficultHotseatCount,
      diceValues,
      this.rollQuadDice,
      this.roll,
      this.playDifficultHotseat,
      justFinishedQuadDice,
      displayingRuleDescription,
      this.getBottomOfDiceDisplay
    );

    return this.state.termsConditionsAccepted ? (
      <Fragment>
        {this.state.displayCaptainsHatModal ? <Modal text="The Captain may retire now!" onPress={this.disableCaptainsHatModal}/> : null}
        {this.state.playingTriple7s ? (
          <Triple7s
            startingTime={8}
            stopPlayingTriple7s={this.stopPlayingTriple7s}
          />
        ) : (
          <View style={styles.container}>
            {/* <ShakeDetector roll={this.roll} /> */}
            <View style={styles.upperSection}>
              <RuleDisplay ruleName={rule.name} style={styles.rule} getBottomOfRuleDisplay={this.getBottomOfRuleDisplay}/>
              {this.renderDice(rule)}
            </View>
            {this.renderCard(rule, rollFunction, rollText)}

            {/* only here to hold upper layer up (card is positioned absolutely) */}
            <View style={styles.bottomCard} />
          </View>
        )}
        <Banner />
      </Fragment>
    ) : (
      <TermsAndConditions
        acceptTermsAndConditions={this.acceptTermsAndConditions}
      />
    );
  }
}

const currentRollState = (
  difficultHotseatCount,
  diceValues,
  rollQuadDice,
  roll,
  playDifficultHotseat,
  justFinishedQuadDice,
  getBottomOfDiceDisplay
) => {
  let rollText;
  let rollFunction;

  const rule = computeRule(diceValues);

  if (isPlayingDifficultHotseat(difficultHotseatCount)) {
    rollText = difficultHotseatButtonPrompts[difficultHotseatCount];
    rollFunction = playDifficultHotseat;
    return {
      rollFunction,
      rollText,
    };
  } else if (rule === rules.quadDice && !justFinishedQuadDice) {
    return {
      rollFunction: rollQuadDice,
      rollText: "ROLL QUAD DICE",
    };
  }

  return {
    rollFunction: roll,
    rollText: "NEXT ROLL",
  };
};

export const isPlayingDifficultHotseat = difficultHotseatCount =>
  difficultHotseatCount !== null;

const Banner = () => <View style={styles.banner} />;

const MainDice = ({ diceValues, difficultHotseatCount, getBottomOfDiceDisplay }) => (
  <Dice
    diceValues={diceValues}
    style={styles.dice}
    shouldRoll={!difficultHotseatCount}
    getBottomOfDiceDisplay={getBottomOfDiceDisplay}
  />
);

const sumArray = arr => arr.reduce((total, num) => total + num);

const difficultHotseatButtonPrompts = {
  0: "VIEW 1ST QUESTION",
  1: "VIEW 2ND QUESTION",
  2: "VIEW 3RD QUESTION",
  3: "VIEW 4TH QUESTION",
  4: "VIEW 5TH QUESTION",
  5: "DISMISS",
};

const styles = StyleSheet.create({
  container: {
    flex: 8,
    backgroundColor: global.debug ? "orange" : "#ac0000",
    padding: 30,
    paddingTop: 50,
    paddingBottom: 10,
  },
  upperSection: {
    flex: 5,
    backgroundColor: "transparent",
  },
  bottomCard: {
    flex: 4,
  },
  ruleContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  dice: {
    flex: 7,
  },
  rule: {
    flex: 5,
  },
  banner: {
    height: 50,
    backgroundColor: "lightgrey",
  },
});

export default App;
