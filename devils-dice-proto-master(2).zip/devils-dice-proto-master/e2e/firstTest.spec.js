const { reloadApp } = require('detox-expo-helpers');

describe('Example', () => {
  beforeEach(async () => {
    console.log('reloading app...')
    await reloadApp();
    console.log('app reloaded')
  });

  it('should have welcome screen', async () => {
    console.log('????')
    await expect(element(by.id('welcome'))).toBeVisible();
    console.log('done');
  });
});