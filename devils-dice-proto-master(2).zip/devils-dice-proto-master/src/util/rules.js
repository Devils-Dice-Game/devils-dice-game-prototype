const ruleNames = {
  captainsHat: "CAPTAIN'S HAT",
  loseClothing: "LOSE CLOTHING",
  deathCup: "DEATH CUP",
  quadDice: "QUAD DICE",
  difficultHotseat: "DIFFICULT HOTSEAT",
  babyBird: "BABY BIRD",
  rollerFinishes: "ROLLER FINISHES",
  hotseat: "HOTSEAT",
  aB: "A + B",
  paranoia: "PARANOIA",
  socials: "SOCIALS",
  reverseHotseat: "REVERSE HOTSEAT",
  mostLikely: "MOST LIKELY",
  neverHaveIEver: "NEVER HAVE I EVER",
  selectFinisher: "SELECT FINISHER",
  everyoneFinishes: "EVERYONE FINISHES",
  welcomeRule: "DEVIL'S DICE",
};

export const rules = {
  welcomeRule: {
    name: ruleNames.welcomeRule,
    description: "WELCOME TO\n😈 👹 DEVIL'S DICE 👹 😈",
  },
  captainsHat: {
    name: ruleNames.captainsHat,
    description: `Roller has to put an object on their head (signifying that they are the Captain or everyone’s mate), and drink every time someone else has to drink.`,
  },
  loseClothing: {
    name: ruleNames.loseClothing,
    description: `Roller must remove two articles of clothing for the remainder of the game. If the roller choses not to, they must finish a full drink.`,
  },
  deathCup: {
    name: ruleNames.deathCup,
    description: `Everyone at the table pours some of their drink into a cup. The roller then has to finish the contents of that cup.`,
  },
  quadDice: {
    name: ruleNames.quadDice,
    description: `The Roller rolls four dice, the total value of the roll is how long the Roller has to drink for.`,
  },
  difficultHotseat: {
    name: ruleNames.difficultHotseat,
    description: `Roller must answer the next five questions.`,
  },
  babyBird: {
    name: ruleNames.babyBird,
    description: `Player to the Roller's left must pour some of their drink into their mouth, and feed it into the Roller. Like a Baby Bird. If the roller choses not to, they must finish a full drink.`,
  },
  rollerFinishes: {
    name: ruleNames.rollerFinishes,
    description: `Roller finishes their drink.`,
  },
  hotseat: {
    name: ruleNames.hotseat,
    description: `Everyone playing gets to ask the roller a question. Roller can either answer or drink. Eight or more people and only the opposite sex gets to ask the questions.`,
  },
  aB: {
    name: ruleNames.aB,
    description: `Roller blinds themself. The person to the Roller's left selects person A, and person to the right selects person B. Roller then says a scenario of what A must do to B, B must do to A, or A and B must do with each other. Without knowing who A or B are.`,
  },
  paranoia: {
    name: ruleNames.paranoia,
    description: `Roller whispers a question to the person on their left. The person to the left then points at who they think the question applies to. If the selected person wants to find out what the question was, they have to drink for 10 seconds.`,
  },
  socials: {
    name: ruleNames.socials,
    description: `Everyone at the table drinks. If three 7s are rolled in a row, everyone playing has to finish their drinks.`,
  },
  reverseHotseat: {
    name: ruleNames.reverseHotseat,
    description: `Roller asks one question that everyone has to answer. If a person doesn’t want to answer then they have to drink. Eight or more people and only the opposite sex has to answer the question.`,
  },
  mostLikely: {
    name: ruleNames.mostLikely,
    description: `Roller selects a Most Likely scenario. After the count of 3 everyone at the table points at who they think are most likely to do that. Everyone has to drink the amount of fingers pointing at them.`,
  },
  neverHaveIEver: {
    name: ruleNames.neverHaveIEver,
    description: `All players put up three fingers. Starting with the roller, name something that you haven’t done. Everyone that has done it, claps, drinks, and loses a finger. The game is played until someone loses all three fingers.`,
  },
  selectFinisher: {
    name: ruleNames.selectFinisher,
    description: `Select someone at the table to finish their drink!`,
  },
  everyoneFinishes: {
    name: ruleNames.everyoneFinishes,
    description: `Roller finishes their drink.... Sucker.`,
  },
};

// for debugging stuff
const getRandomInt = (min, max) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
};

export const computeRule = diceValues => {
  const [die1, die2] = diceValues;

  const sum = die1 + die2;

  if (die1 === 1 && die2 === 1) {
    return rules.captainsHat;
  } else if (die1 === 2 && die2 === 2) {
    return rules.loseClothing;
  } else if (die1 === 3 && die2 === 3) {
    return rules.deathCup;
  } else if (die1 === 4 && die2 === 4) {
    return rules.quadDice;
  } else if (die1 === 5 && die2 === 5) {
    return rules.difficultHotseat;
  } else if (die1 === 6 && die2 === 6) {
    return rules.babyBird;
  } else if (sum === 3) {
    return rules.rollerFinishes;
  } else if (sum === 4) {
    return rules.hotseat;
  } else if (sum === 5) {
    return rules.aB;
  } else if (sum === 6) {
    return rules.paranoia;
  } else if (sum === 7) {
    return rules.socials;
  } else if (sum === 8) {
    return rules.reverseHotseat;
  } else if (sum === 9) {
    return rules.mostLikely;
  } else if (sum === 10) {
    return rules.neverHaveIEver;
  } else if (sum === 11) {
    return rules.selectFinisher;
  } else return rules.welcomeRule;
};
