import { rules } from "./rules";
import abDares from "../dares/ab";
import paranoiaDares from "../dares/paranoia";
import hotseatDares from "../dares/hotseat";
import mostLikelyDares from "../dares/mostLikely";

const generateDare = dares =>
  dares[Math.floor(Math.random() * Math.floor(dares.length))];

const getNewDare = rule => {
  if (rule === rules.aB) {
    return generateDare(abDares);
  } else if (rule === rules.paranoia) {
    return generateDare(paranoiaDares);
  } else if (
    rule === rules.hotseat ||
    rule === rules.reverseHotseat ||
    rule === rules.difficultHotseat
  ) {
    return generateDare(hotseatDares);
  } else if (rule === rules.mostLikely) {
    return generateDare(mostLikelyDares);
  } else return undefined;
};

export default getNewDare;
