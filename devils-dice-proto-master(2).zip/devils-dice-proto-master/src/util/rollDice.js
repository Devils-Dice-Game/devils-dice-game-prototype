import { rules } from "./rules";

const rollDie = () => Math.floor(Math.random() * Math.floor(6)) + 1;

// for debugging stuff
const getRandomInt = (min, max) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
};

const rollDice = diceCount => {
  let dice = [];
  for (let diceRoll = 0; diceRoll < diceCount; diceRoll++) {
    dice.push(rollDie());
  }

  // if(getRandomInt(1, 3) === 2 && diceCount === 2) {
  //   return [1,1]
  // }

  return dice;
};

export const isTriple7s = rolls => {
  const lastThreeRolls = rolls.slice(rolls.length - 3);

  const socials = rules.socials.name;

  if (
    lastThreeRolls[0] === socials &&
    lastThreeRolls[1] === socials &&
    lastThreeRolls[2] === socials
  ) {
    return true;
  }

  return false;
};

export default rollDice;
