import React from "react";
import { StyleSheet, Text, TouchableHighlight, View } from "react-native";

const RuleDisplay = ({ ruleName, style, getBottomOfRuleDisplay }) => {
  return (
    <View
      style={[styles.rule, style]}
      onLayout={event => {
        getBottomOfRuleDisplay(event);
      }}
    >
      <Text style={styles.ruleText}>{ruleName}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rule: {
    backgroundColor: global.debug ? "lightgray" : "transparent",
    justifyContent: "center",
    alignItems: "center",
  },
  ruleText: {
    color: "white",
    fontSize: 48,
    fontWeight: "bold",
    textAlign: "center",

    textShadowColor: "#161616",
    textShadowOffset: { width: 3, height: 4 },
    textShadowRadius: 5,
  },
});

export default RuleDisplay;
