import React from "react";
import {
  StyleSheet,
  ScrollView,
  Text,
  TouchableHighlight,
  TouchableOpacity,
  View,
  Linking,
} from "react-native";

import appData from "../../app.json";

const Header = ({ children, style }) => (
  <Text style={[styles.headers, style]}>{children} </Text>
);
const FinePrint = ({ children, style }) => (
  <Text style={[styles.finePrint, style]}>{children} </Text>
);

const TermsAndConditions = ({ acceptTermsAndConditions }) => (
  <View style={styles.container} testID="welcome">
    <ScrollView style={styles.container}>
      <Header style={{ fontSize: 50, paddingTop: 50 }}>
        Terms and Conditions
      </Header>
      <FinePrint>Last updated: January 23, 2019</FinePrint>
      <FinePrint>Beta version {appData.expo.version}</FinePrint>
      <FinePrint>
        Please read these Terms and Conditions (“Terms”, “Terms and Conditions”)
        carefully before using the Devil’s Dice Game mobile application (the
        “Service”) operated by Devil’s Dice Game (“us”, “we”, or “our”). Your
        access to and use of the Service is conditioned on your acceptance of
        and compliance with these Terms. These Terms apply to all visitors,
        users and others who access or use the Service. You warrant that you are
        at least 18-years-old and you are legally capable of entering into
        binding contracts. If you are under 18-years-old, you warrant that you
        have obtained consent from your parent or guardian and they agree to be
        bound by these Terms on your behalf. By accessing or using the Service
        you agree to be bound by these Terms. If you disagree with any part of
        the terms then you may not access the Service.
      </FinePrint>
      <Header>Accounts</Header>
      <FinePrint>
        When you create an account with us, you must provide us information that
        is accurate, complete, and current at all times. Failure to do so
        constitutes a breach of the Terms, which may result in immediate
        termination of your account on our Service. You are responsible for
        safeguarding the password that you use to access the Service and for any
        activities or actions under your password, whether your password is with
        our Service or a third-party service. You agree not to disclose your
        password to any third party. You agree to be fully responsible for
        activities that relate to your account or your password. You must notify
        us immediately upon becoming aware of any breach of security or
        unauthorized use of your account.
      </FinePrint>
      <Header>Intellectual Property</Header>
      <FinePrint>
        The Service and its original content, features and functionality are and
        will remain the exclusive property of Devil’s Dice Game, Kurtis H Bryant
        (ABN 96 782 123 075) and its licensors. The Service is protected by
        copyright, trademark, and other laws of both the Australia and foreign
        countries. Our trademarks and trade dress may not be used in connection
        with any product or service without the prior written consent of Devil’s
        Dice Game. Nothing in these Terms constitutes a transfer of any
        Intellectual Property rights from us to you.
      </FinePrint>
      <Header>Links To Other Web Sites</Header>
      <FinePrint>
        Our Service may contain links to third-party web sites or services that
        are not owned or controlled by Devil’s Dice Game. Devil’s Dice Game has
        no control over, and assumes no responsibility for, the content, privacy
        policies, or practices of any third party web sites or services. You
        further acknowledge and agree that Devil’s Dice Game shall not be
        responsible or liable, directly or indirectly, for any damage or loss
        caused or alleged to be caused by or in connection with use of or
        reliance on any such content, goods or services available on or through
        any such web sites or services. We only provide links to external
        websites as a convenience, and the inclusion of such a link to external
        websites do not imply our endorsement of those websites. You acknowledge
        and agree that when you access other websites on the Internet, you do so
        at your own risk. We strongly advise you to read the terms and
        conditions and privacy policies of any third-party web sites or services
        that you visit.
      </FinePrint>
      <Header>Termination</Header>
      <FinePrint>
        We may terminate or suspend your account immediately, without prior
        notice or liability, for any reason whatsoever, including without
        limitation if you breach the Terms. Upon termination, your right to use
        the Service will immediately cease. If you wish to terminate your
        account, you may simply discontinue using the Service. All provisions of
        the Terms which by their nature should survive termination shall survive
        termination, including, without limitation, ownership provisions,
        warranty disclaimers, indemnity and limitations of liability. We shall
        not be liable to you or any third party for any claims or damages
        arising out of any termination or suspension or any other actions taken
        by us in connection therewith. If applicable law requires us to provide
        notice of termination or cancellation, we may give prior or subsequent
        notice by posting it on the Service or by sending a communication to any
        address (email or otherwise) that we have for you in our records.
      </FinePrint>
      <Header>Governing Law</Header>
      <FinePrint>
        These Terms shall be governed and construed in accordance with the laws
        of Queensland, Australia, without regard to its conflict of law
        provisions. Our failure to enforce any right or provision of these Terms
        will not be considered a waiver of those rights. If any provision of
        these Terms is held to be invalid or unenforceable by a court, the
        remaining provisions of these Terms will remain in effect. These Terms
        constitute the entire agreement between us regarding our Service, and
        supersede and replace any prior agreements we might have between us
        regarding the Service.
      </FinePrint>
      <Header>Changes</Header>
      <FinePrint>
        We reserve the right, at our sole discretion, to modify or replace these
        Terms at any time. If a revision is material we will try to provide at
        least 30 days notice prior to any new terms taking effect. It is your
        sole responsibility to periodically check these Terms for any changes.
        If you do not agree with any of the changes to these Terms, it is your
        sole responsibility to stop using the Service. Your continued use of the
        Service will be deemed as your acceptance thereof.
      </FinePrint>
      <Header>Contact Us</Header>
      <FinePrint>
        If you have any questions about these Terms, please contact us.
      </FinePrint>

      <TouchableOpacity
        onPress={() => Linking.openURL("mailto:info@devilsdicegame.com")}
      >
        <FinePrint style={{ color: "blue" }}>info@devilsdicegame.com</FinePrint>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => Linking.openURL("http://www.devilsdicegame.com")}
      >
        <FinePrint style={{ color: "blue", paddingBottom: 30 }}>
          www.devilsdicegame.com
        </FinePrint>
      </TouchableOpacity>
    </ScrollView>
    <TouchableHighlight
      style={styles.acceptButton}
      onPress={acceptTermsAndConditions}
    >
      <Text style={styles.acceptText}>ACCEPT TERMS AND CONDITIONS</Text>
    </TouchableHighlight>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
  },
  headers: {
    fontSize: 30,
    fontWeight: "bold",
    paddingTop: 20,
    borderTopWidth: 20,
    justifyContent: "center",
    textAlign: "center",
    backgroundColor: "white",
  },
  finePrint: {
    fontSize: 15,
    fontWeight: "bold",
    paddingLeft: 10,
    paddingRight: 10,
    borderTopWidth: 20,
    justifyContent: "center",
    textAlign: "center",
    backgroundColor: "white",
  },
  acceptButton: {
    flex: 1,
    maxHeight: "10%",
    backgroundColor: "red",
    justifyContent: "center",
    paddingBottom: 15,
  },
  acceptText: {
    color: "white",
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
  },
});

export default TermsAndConditions;
