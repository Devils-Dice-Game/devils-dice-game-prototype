import React from "react";
import { Accelerometer } from "expo";

class ShakeDetector extends React.PureComponent {
  state = {
    lastRolled: null,
  };

  accelerometerData = null;

  componentDidMount() {
    this._toggle();
    Accelerometer.setUpdateInterval(500);
  }

  componentWillUnmount() {
    this._unsubscribe();
  }

  _toggle = () => {
    if (this._subscription) {
      this._unsubscribe();
    } else {
      this._subscribe();
    }
  };

  _subscribe = () => {
    this._subscription = Accelerometer.addListener(accelerometerData => {
      if (this.accelerometerData) {
        const { x } = accelerometerData;
        const prevX = this.accelerometerData.x;

        const xDelta = Math.abs(x - prevX);
        const timeSinceLastRoll = new Date().getTime() - this.state.lastRolled;

        if (xDelta > 0.5 && timeSinceLastRoll > 5000) {
          this.setState({
            lastRolled: new Date().getTime(),
          });
          this.props.roll();
        }
      }
      this.accelerometerData = accelerometerData;
    });
  };

  _unsubscribe = () => {
    this._subscription && this._subscription.remove();
    this._subscription = null;
  };

  render() {
    return null;
  }
}

export default ShakeDetector;
