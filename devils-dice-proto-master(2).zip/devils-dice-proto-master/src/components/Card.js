import React, { Fragment } from "react";
import { View } from "react-native";
import GenerateDare from "./GenerateDare";
import { AntDesign } from '@expo/vector-icons';
import {
  StyleSheet,
  Text,
  TouchableHighlight,
  TouchableOpacity,
  Animated,
  ScrollView,
} from "react-native";

const Caret = ({ shouldPointDown }) => (
  <View style={{
    flexDirection: 'row',
    justifyContent: 'center',
  }}>
    <AntDesign name={shouldPointDown ? "down" : "up"} size={20} color="grey"/>
  </View>
)

const Button = ({ onPress, children, style }) => (
  <View
    style={styles.buttonContainer}
    shadowOffset={{
      height: 5,
      width: 5,
    }}
    shadowRadius={4}
    shadowOpacity={0.25}
  >
    <TouchableHighlight
      style={[styles.primaryButton, styles.button, style]}
      onPress={onPress}
    >
      <Text style={styles.buttonText}>{children}</Text>
    </TouchableHighlight>
  </View>
);

const shortCard = 350;
const expandedCard = 550;

class Card extends React.Component {
  state = {
    expandedCard: false,
    slideAnim: new Animated.Value(shortCard),
  };

  componentDidUpdate = prevProps => {
    if (
      this.props.textToDisplay !== prevProps.textToDisplay &&
      !this.props.displayingDare
    ) {
      // pull down for a new game description
      Animated.timing(this.state.slideAnim, {
        toValue: shortCard,
        duration: 200,
      }).start();

      this.setState({
        expandedCard: false,
      });
    } else if (this.props.displayingDare !== prevProps.displayingDare) {
      // pull up for a new dare display
      Animated.timing(this.state.slideAnim, {
        toValue: this.props.maxHeight,
        duration: 200,
      }).start();

      this.setState({
        expandedCard: false,
      });
    }
  };

  toggleCardHeight = () => {
    if (this.state.expandedCard) {
      Animated.timing(this.state.slideAnim, {
        toValue: shortCard,
        duration: 200,
      }).start();
    } else {
      Animated.timing(this.state.slideAnim, {
        toValue: this.props.maxHeight,
        duration: 200,
      }).start();
    }

    this.setState(prevState => ({
      expandedCard: !prevState.expandedCard,
    }));
  };

  render() {
    const {
      dare,
      displayDare,
      primaryButtonFunction,
      rollText,
      playingDifficultHotseat,
      style,
      textToDisplay,
      displayingDare,
    } = this.props;

    let { slideAnim } = this.state;

    const displayDareButton = dare && !playingDifficultHotseat;
    const secondaryButton = {
      style: {
        backgroundColor: displayDareButton ? "#274c68" : "transparent",
      },
      text: displayDareButton ? this.props.ruleName : null,
    };

    const textStyle = displayingDare ? styles.dareText : styles.ruleDescription;

    return (
      <Animated.View
        style={{ ...styles.card, height: slideAnim }}
        shadowColor={"black"}
        shadowOffset={{
          height: 8,
          width: 8,
        }}
        shadowRadius={2}
        shadowOpacity={0.2}
      > 
      { displayingDare ? null : <Caret shouldPointDown={this.state.expandedCard} />}
        <OptionalScrollView scroll={this.state.expandedCard}>
          <TouchableHighlight
            onPress={displayingDare ? null : this.toggleCardHeight}
            underlayColor={"white"}
            style={styles.descriptionContainer}
          >
          <Fragment>
            {getText(
              this.state.expandedCard,
              displayingDare,
              textToDisplay,
              textStyle
            )}
            </Fragment>
          </TouchableHighlight>
        </OptionalScrollView>
        {secondaryButton.text ? (
          <Button onPress={displayDare} style={secondaryButton.style}>
            {secondaryButton.text}
          </Button>
        ) : null}
        <Button onPress={primaryButtonFunction} style={styles.rollButton}>
          {rollText}
        </Button>
      </Animated.View>
    );
  }
}

/*
  Opening dare, where you'd expect expanded scrollview, is janky
  This is a weird shitty half workaround
*/
const getText = (expandedCard, displayingDare, text, textStyle) => {
  if (expandedCard || displayingDare)
    return <Text style={textStyle}>{text}</Text>;

  return (
    <Text style={textStyle} numberOfLines={expandedCard ? null : 4}>
      {text}
    </Text>
  );
};

const OptionalScrollView = ({ scroll, children }) =>
  scroll ? (
    <ScrollView style={{ flex: 1, padding: 10 }}>{children}</ScrollView>
  ) : (
    children
  );

const styles = StyleSheet.create({
  card: {
    backgroundColor: global.debug ? "yellow" : "white",
    padding: 20,
    borderRadius: 50,
    position: "absolute",
    bottom: 20,
    left: 10,
    right: 10,
    zIndex: 1,
  },
  descriptionContainer: {
    flex: 2,
    justifyContent: "center",
  },
  ruleDescription: {
    fontSize: 25,
    textAlign: "center",
    flex: 4,
  },
  dareText: {
    fontSize: 35,
    color: "black",
    textAlign: "center",
    textShadowColor: "#ac0000",
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
    flex: 4,
  },
  buttonContainer: {
    padding: 5,
    backgroundColor: global.debug ? "black" : "transparent",
    justifyContent: "center",
    alignItems: "center",
  },
  button: {
    alignItems: "center",
    justifyContent: "center",
    width: "85%",
    height: 70,
    borderRadius: 10,
    bottom: 10,
  },
  buttonText: {
    color: "white",
    fontSize: 25,
    fontWeight: "bold",
    textAlign: "center",
  },
  primaryButton: {
    backgroundColor: "#ac0000",
  },
});

export default Card;
