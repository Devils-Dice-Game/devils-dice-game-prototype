import React from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
  Image,
} from "react-native";
const logo = require("../../assets/logo.png");

const GenerateDare = ({ displayNewDare, dareActive }) => (
  <View style={styles.buttonContainer}>
    {!dareActive ? (
      <View style={styles.logoContainer}>
        <Image source={logo} style={styles.logo} />
      </View>
    ) : (
      <TouchableHighlight
        style={[styles.generateRule, styles.buttons]}
        onPress={displayNewDare}
      >
        <Text style={styles.buttonText}>GENERATE DARE</Text>
      </TouchableHighlight>
    )}
  </View>
);

const styles = StyleSheet.create({
  buttons: {
    borderColor: "black",
    borderStyle: "solid",
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    color: "white",
    fontSize: 30,
    fontWeight: "bold",
    textAlign: "center",
  },
  buttonContainer: {
    flex: 1,
    backgroundColor: "white",
    flexDirection: "row",
  },
  logoContainer: {
    flex: 1,
    backgroundColor: "white",
    justifyContent: "center",
    alignItems: "center",
  },
  logo: {
    flex: 1,
    width: "50%",
    height: "auto",
  },
  generateRule: {
    flex: 1,
    backgroundColor: "#3f0000",
  },
});

export default GenerateDare;
