import React, { Fragment } from "react";
import { StyleSheet, Image, TouchableOpacity, View, Text } from "react-native";

const one = require("../../assets/1.png");
const two = require("../../assets/2.png");
const three = require("../../assets/3.png");
const four = require("../../assets/4.png");
const five = require("../../assets/5.png");
const six = require("../../assets/6.png");

const getDie = value => {
  let die;

  switch (value) {
    case 1:
      die = one;
      break;
    case 2:
      die = two;
      break;
    case 3:
      die = three;
      break;
    case 4:
      die = four;
      break;
    case 5:
      die = five;
      break;
    case 6:
      die = six;
      break;
    default:
      die = undefined;
      break;
  }

  return die;
};

class Die extends React.Component {
  render() {
    return (
      <View style={styles.die}>
        <Image source={getDie(this.props.value)} style={this.props.style} />
      </View>
    );
  }
}

const sumArray = arr => arr.reduce((total, num) => total + num);

const QuadDice = ({ diceValues, clearMinigame, style }) => {
  const dieSize = 300 / diceValues.length;

  return (
    <Fragment>
      <TouchableOpacity style={styles.dice} onPress={clearMinigame}>
        {diceValues.map((dieValue, index) => (
          <Die
            value={dieValue}
            key={index}
            style={{ height: dieSize, width: dieSize }}
          />
        ))}
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.instructionContainer}
        onPress={clearMinigame}
      >
        <Text style={styles.text}>
          Drink for {sumArray(diceValues)} seconds!
        </Text>
      </TouchableOpacity>
    </Fragment>
  );
};

const styles = StyleSheet.create({
  dice: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    backgroundColor: "#fff",
    paddingTop: 100,
  },
  die: {
    margin: 10,
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  instructionContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "white",
  },
  text: {
    textAlign: "center",
    fontSize: 30,
    fontWeight: "bold",
  },
});

export default QuadDice;
