import React from "react";
import { View, Text, StyleSheet } from "react-native";

class Triple7s extends React.Component {
  state = {
    timer: this.props.startingTime,
  };

  componentDidMount() {
    this._mounted = true;
    this.decrementTimer();
  }

  componentWillUnmount() {
    this._mounted = false;
  }

  decrementTimer = () => {
    setTimeout(() => {
      if (this._mounted)
        this.setState(prevState => ({
          timer: prevState.timer - 1,
        }));
    }, 1000);
  };

  componentDidUpdate() {
    if (this.state.timer >= 0) {
      this.decrementTimer();
    } else {
      this.props.stopPlayingTriple7s();
    }
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.directions}>TRIPLE 7!</Text>
        <Text style={styles.directions}>EVERYBODY FINISH THEIR DRINKS</Text>
        <Text style={styles.directions}>!!!!!!!!!!!!!!!</Text>
        <Text style={styles.number}>{this.state.timer}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ac0000",
    justifyContent: "center",
    alignItems: "center",
  },
  directions: {
    color: "white",
    fontWeight: "bold",
    fontSize: 50,
    textAlign: "center",
    marginBottom: 20,
  },
  number: {
    color: "white",
    fontWeight: "bold",
    fontSize: 100,
  },
});

export default Triple7s;
