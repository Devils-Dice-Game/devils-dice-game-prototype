import React from "react";
import { StyleSheet, Text, TouchableHighlight } from "react-native";

const Dare = ({ dare, disableDareDisplay }) => {
  return (
    <TouchableHighlight style={styles.container} onPress={disableDareDisplay}>
      <Text style={styles.description}>{dare}</Text>
    </TouchableHighlight>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "red",
    paddingTop: 50,
  },
  description: {
    flex: 1,
    fontSize: 30,
    fontWeight: "bold",
    padding: 30,
    paddingBottom: 100,
    borderTopWidth: 20,
    justifyContent: "center",
    textAlign: "center",
    color: "white",
  },
});

export default Dare;
