import React, { Fragment } from "react";
import { View } from "react-native";
import {
  StyleSheet,
  Text,
  TouchableHighlight,
  TouchableOpacity,
} from "react-native";

const Button = ({ onPress, children, style }) => (
  <View style={styles.buttonContainer}>
    <TouchableHighlight style={[styles.button, style]} onPress={onPress}>
      <Text style={styles.buttonText}>{children}</Text>
    </TouchableHighlight>
  </View>
);

const DareModal = ({ text, onPress }) => {
  return (
    <Fragment>
      <TouchableOpacity style={styles.dareModalOverlay} onPress={onPress} />
      <View style={styles.dareModal}>
        <View style={styles.modalElementContainer}>
          <Text style={styles.dareModalText}>{text}</Text>
          <Button onPress={onPress}>Close</Button>
        </View>
      </View>
    </Fragment>
  );
};

const styles = StyleSheet.create({
  dareModalOverlay: {
    backgroundColor: "black",
    position: "absolute",
    opacity: 0.9,
    width: "100%",
    height: "100%",
    zIndex: 1,
  },
  dareModal: {
    position: "absolute",
    top: 100,
    marginLeft: "auto",
    marginRight: "auto",
    padding: 10,
    minHeight: 100,
    width: "100%",
    zIndex: 2,
  },
  modalElementContainer: {
    backgroundColor: "#ac0000",
    flex: 1,
    borderRadius: 20,
    padding: 20,
  },
  dareModalText: {
    fontSize: 30,
    color: "white",
    textAlign: "center",
    flex: 1,
    marginBottom: 50,
    fontWeight: "bold",
  },
  button: {
    flex: 1,
    backgroundColor: "black",
    borderRadius: 50,
    margin: 10,
    padding: 5,
  },
  buttonText: {
    fontSize: 35,
    textAlign: "center",
    color: "white",
  },
});

export default DareModal;
