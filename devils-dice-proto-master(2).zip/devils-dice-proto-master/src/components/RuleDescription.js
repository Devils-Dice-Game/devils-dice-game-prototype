import React from "react";
import { StyleSheet, Text, TouchableHighlight, ScrollView } from "react-native";

// NOT TESTED because ScrollView does not render
// https://github.com/expo/expo/issues/2484
const RuleDescription = ({ description, onPress }) => (
  <ScrollView style={styles.ruleContainer}>
    <TouchableHighlight onPress={onPress}>
      <Text style={styles.ruleDescription}>{description}</Text>
    </TouchableHighlight>
  </ScrollView>
);

const styles = StyleSheet.create({
  ruleContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  ruleDescription: {
    flex: 1,
    fontSize: 30,
    fontWeight: "bold",
    padding: 50,
    paddingBottom: 100,
    borderTopWidth: 20,
    justifyContent: "center",
    textAlign: "center",
    backgroundColor: "white",
  },
});

export default RuleDescription;
