import React from "react";
import {
  StyleSheet,
  Image,
  TouchableOpacity,
  Animated,
  View,
} from "react-native";

const one = require("../../assets/1.png");
const two = require("../../assets/2.png");
const three = require("../../assets/3.png");
const four = require("../../assets/4.png");
const five = require("../../assets/5.png");
const six = require("../../assets/6.png");

const getDie = value => {
  let die;

  switch (value) {
    case 1:
      die = one;
      break;
    case 2:
      die = two;
      break;
    case 3:
      die = three;
      break;
    case 4:
      die = four;
      break;
    case 5:
      die = five;
      break;
    case 6:
      die = six;
      break;
    default:
      die = undefined;
      break;
  }

  return die;
};

const diceRestPosition = 250;

class Die extends React.Component {
  state = {
    slideAnim: new Animated.Value(diceRestPosition),
  };

  componentDidMount() {
    Animated.timing(this.state.slideAnim, {
      toValue: 0,
      duration: diceRestPosition,
    }).start();
  }

  componentDidUpdate() {
    if (this.props.shouldRoll) {
      Animated.sequence([
        Animated.timing(this.state.slideAnim, {
          toValue: diceRestPosition,
          duration: diceRestPosition,
        }),
        Animated.timing(this.state.slideAnim, {
          toValue: 0,
          duration: diceRestPosition,
        }),
      ]).start();
    }
  }

  render() {
    let { slideAnim } = this.state;
    return (
      <View
        onLayout={event => {
          this.props.getBottomOfDiceDisplay(event);
        }}
      >
        <Animated.View
          style={{ ...styles.die, top: slideAnim }}
          shadowColor={"black"}
          shadowOffset={{
            height: 10,
            width: 10,
          }}
          shadowRadius={2}
          shadowOpacity={0.6}
        >
          <Image
            source={getDie(this.props.value)}
            style={[styles.image, this.props.style]}
          />
        </Animated.View>
      </View>
    );
  }
}

// get proportions of dice, diff for normal/quad dice
const getDieDimensions = diceValues => {
  const numerator = diceValues === 2 ? 270 : 230;

  return numerator / diceValues.length;
};

const Dice = ({
  diceValues,
  clearMinigame,
  shouldRoll,
  getBottomOfDiceDisplay,
  style,
}) => {
  // should only happen for start of game
  if (diceValues.length === 0) diceValues = [1, 1];

  const dieSize = getDieDimensions(diceValues);

  return (
    <TouchableOpacity style={[styles.dice, style]} onPress={clearMinigame}>
      {diceValues.map((dieValue, index) => (
        <Die
          value={dieValue}
          key={index}
          style={{ height: dieSize, width: dieSize }}
          shouldRoll={shouldRoll}
          getBottomOfDiceDisplay={getBottomOfDiceDisplay}
        />
      ))}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  dice: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    backgroundColor: global.debug ? "white" : "transparent",
    paddingBottom: 100,
  },
  die: {
    position: "relative",
    margin: 10,
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: global.debug ? "white" : "transparent",
  },
  image: {
    borderRadius: 20,
  },
});

export default Dice;
