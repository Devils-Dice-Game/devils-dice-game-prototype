# devils-dice-proto

## Quickstart
clone the project

`$ git clone git@github.com:lukebelliveau/devils-dice-proto.git`

navigate to project root

`$ cd devils-dice-proto`

install dependencies

`$ yarn`

start

`$ yarn start`

The terminal will display a QR code. Scan it in the expo app to launch `devils-dice-proto`