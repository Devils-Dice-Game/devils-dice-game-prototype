module.exports = {
  extends: ["react-app", "prettier"]
};
