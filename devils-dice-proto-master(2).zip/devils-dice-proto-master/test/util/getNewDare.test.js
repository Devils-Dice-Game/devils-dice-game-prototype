import getNewDare from "../../src/util/getNewDare";
import { rules } from "../../src/util/rules";
import abDares from "../../src/dares/ab";
import paranoiaDares from "../../src/dares/paranoia";
import hotseatDares from "../../src/dares/hotseat";
import mostLikelyDares from "../../src/dares/mostLikely";

describe("getNewDare()", () => {
  it("returns a dare for A + B", () => {
    const aB = rules.aB;

    const dare = getNewDare(aB);

    expect(abDares.includes(dare)).toBe(true);
  });

  it("returns a dare for Paranoia", () => {
    const paranoia = rules.paranoia;

    const dare = getNewDare(paranoia);

    expect(paranoiaDares.includes(dare)).toBe(true);
  });

  it("returns a dare for Hotseat", () => {
    const hotseat = rules.hotseat;

    const dare = getNewDare(hotseat);

    expect(hotseatDares.includes(dare)).toBe(true);
  });

  it("returns a dare for Difficult Hotseat", () => {
    const difficultHotseat = rules.difficultHotseat;

    const dare = getNewDare(difficultHotseat);

    expect(hotseatDares.includes(dare)).toBe(true);
  });

  it("returns a dare for Reverse Hotseat", () => {
    const reverseHotseat = rules.reverseHotseat;

    const dare = getNewDare(reverseHotseat);

    expect(hotseatDares.includes(dare)).toBe(true);
  });

  it("returns a dare for Most Likely", () => {
    const mostLikely = rules.mostLikely;

    const dare = getNewDare(mostLikely);

    expect(mostLikelyDares.includes(dare)).toBe(true);
  });
});
