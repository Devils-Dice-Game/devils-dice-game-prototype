import rollDice, { isTriple7s } from "../../src/util/rollDice";
import { rules } from "../../src/util/rules";

const getRandomInt = (min, max) => {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
};

describe("rollDice", () => {
  it("returns X amount of dice with values between 1 and 6", () => {
    const diceCount = getRandomInt(1, 4);
    const dice = rollDice(diceCount);

    dice.forEach(dieRoll => {
      expect(dieRoll).toBeGreaterThanOrEqual(1);
      expect(dieRoll).toBeLessThanOrEqual(6);
    });
  });
});

describe("isTriple7s", () => {
  describe("triple 7s have occurred", () => {
    it("returns true when 3 of 3 rolls are SOCIALS", () => {
      const rolls = [
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
      ];

      expect(isTriple7s(rolls)).toBe(true);
    });

    it("returns true when 3 of last 10 rolls are SOCIALS", () => {
      const rolls = [
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
        rules.socials.name,
      ];

      expect(isTriple7s(rolls)).toBe(true);
    });
  });

  describe("triple 7s have NOT occurred", () => {
    it("returns false when 0 of 3 rolls are SOCIALS", () => {
      const rolls = [
        rules.aB.name,
        rules.deathCup.name,
        rules.neverHaveIEver.name,
      ];

      expect(isTriple7s(rolls)).toBe(false);
    });

    it("returns false when 1 of 3 rolls are SOCIALS", () => {
      const rolls = [
        rules.socials.name,
        rules.mostLikely.name,
        rules.selectFinisher.name,
      ];

      expect(isTriple7s(rolls)).toBe(false);
    });

    it("returns false when 2 of last 10 rolls are SOCIALS", () => {
      const rollSet1 = [
        rules.aB.name,
        rules.socials.name,
        rules.loseClothing.name,
        rules.socials.name,
        rules.hotseat.name,
        rules.socials.name,
        rules.babyBird.name,
        rules.socials.name,
        rules.loseClothing.name,
        rules.socials.name,
      ];

      const rollSet2 = [
        rules.aB.name,
        rules.socials.name,
        rules.loseClothing.name,
        rules.socials.name,
        rules.hotseat.name,
        rules.socials.name,
        rules.babyBird.name,
        rules.socials.name,
        rules.socials.name,
        rules.captainsHat.name,
      ];

      const rollSet3 = [
        rules.aB.name,
        rules.socials.name,
        rules.loseClothing.name,
        rules.socials.name,
        rules.hotseat.name,
        rules.socials.name,
        rules.babyBird.name,
        rules.everyoneFinishes.name,
        rules.socials.name,
        rules.socials.name,
      ];

      expect(isTriple7s(rollSet1)).toBe(false);
      expect(isTriple7s(rollSet2)).toBe(false);
      expect(isTriple7s(rollSet3)).toBe(false);
    });
  });
});
