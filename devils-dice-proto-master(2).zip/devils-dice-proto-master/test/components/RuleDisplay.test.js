import React from "react";
import RuleDisplay from "../../src/components/RuleDisplay";

import renderer from "react-test-renderer";

const renderRuleDisplay = (
  props = {
    ruleName: "rule name",
    onPress: jest.fn(),
    style: { height: 50, width: 50 },
  }
) => {
  const { ruleName, onPress, style } = props;
  return renderer.create(
    <RuleDisplay ruleName={ruleName} onPress={onPress} style={style} />
  );
};

describe("RuleDisplay component", () => {
  it("displays the name of rule", () => {
    const ruleDisplay = renderRuleDisplay().toJSON();

    expect(ruleDisplay).toMatchSnapshot();
  });
});
