import React from "react";
import DareDisplay from "../../src/components/DareDisplay";

import renderer from "react-test-renderer";

describe("DareDisplay component", () => {
  it("displays current dare description", () => {
    const dareDisplay = renderer.create(<DareDisplay />).toJSON();
    expect(dareDisplay).toMatchSnapshot();
  });
});
