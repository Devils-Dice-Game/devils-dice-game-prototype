import React from "react";
import GenerateDare from "../../src/components/GenerateDare";

import renderer from "react-test-renderer";

const renderGenerateDare = (
  props = {
    displayNewDare: jest.fn(),
    dareActive: null,
  }
) => {
  const { displayNewDare, dareActive } = props;
  return renderer.create(
    <GenerateDare displayNewDare={displayNewDare} dareActive={dareActive} />
  );
};

describe("GenerateDare component", () => {
  it("displays logo when dare is inactive", () => {
    const generateDare = renderGenerateDare({ dareActive: false }).toJSON();

    expect(generateDare).toMatchSnapshot();
  });

  it("displays GENERATE DARE button when dare is active", () => {
    const generateDare = renderGenerateDare({ dareActive: true }).toJSON();

    expect(generateDare).toMatchSnapshot();
  });
});
