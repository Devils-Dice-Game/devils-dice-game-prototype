import React from "react";
import Buttons from "../../src/components/Buttons";

import renderer from "react-test-renderer";

describe("RollButton component", () => {
  it("displays buttons with standard props", () => {
    const rollButton = renderButtons().toJSON();

    expect(rollButton).toMatchSnapshot();
  });
});

const renderButtons = (
  props = {
    dare: "IT'S DARE",
    displayNewDare: jest.fn(),
    rollFunction: jest.fn(),
    rollText: "NEXT ROLL",
    isPlayingDifficultHotseat: false,
    style: { height: 50, width: 50 },
  }
) => {
  const {
    dare,
    displayNewDare,
    rollFunction,
    rollText,
    isPlayingDifficultHotseat,
    style,
  } = props;

  return renderer.create(
    <Buttons
      dare={dare}
      displayNewDare={displayNewDare}
      rollFunction={rollFunction}
      rollText={rollText}
      isPlayingDifficultHotseat={isPlayingDifficultHotseat}
      style={style}
    />
  );
};
