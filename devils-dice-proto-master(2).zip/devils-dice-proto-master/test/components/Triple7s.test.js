import React from "react";
import Triple7s from "../../src/components/Triple7s";

import renderer from "react-test-renderer";

const renderTriple7s = (
  props = {
    startingTime: 8,
    stopPlayingTriple7s: jest.fn(),
  }
) => {
  const { startingTime, stopPlayingTriple7s } = props;

  return renderer.create(
    <Triple7s
      startingTime={startingTime}
      stopPlayingTriple7s={stopPlayingTriple7s}
    />
  );
};

describe("Triple7s component", () => {
  it("starts in proper counting state", () => {
    const triple7s = renderTriple7s().toJSON();

    expect(triple7s).toMatchSnapshot();
  });

  it("counts down and displays timer value", done => {
    const triple7s = renderTriple7s();

    setTimeout(() => {
      const triple7sCounted = triple7s.toJSON();

      expect(triple7sCounted).toMatchSnapshot();
      done();
    }, 1000);
  });

  it("stops playing Triple7s when timer completes", done => {
    const stopPlayingTriple7s = jest.fn();
    renderTriple7s({
      startingTime: 0,
      stopPlayingTriple7s,
    });

    setTimeout(() => {
      expect(stopPlayingTriple7s).toBeCalled();
      done();
    }, 1000);
  });
});
